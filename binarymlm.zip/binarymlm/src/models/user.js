const mongoose = require('mongoose')
const userSchema = new mongoose.Schema({
    name:{
        type:String
    },
    email:{
        type:String
    },
    phone:{
        type:Number
    },
    referenceId:{
        type: mongoose.Schema.Types.ObjectId
    },
    user_code:{
        type:String
    },
    referncePoint:{
        type:Number
    },
    matchingPoint:{
        type:Number
    },
    parent:{
        type: mongoose.Schema.Types.ObjectId
    },
    lc:{
        type: mongoose.Schema.Types.ObjectId
    },
    rc:{
        type: mongoose.Schema.Types.ObjectId
    },
    rootParent: {
        type: mongoose.Schema.Types.ObjectId
    }
})
module.exports = mongoose.model('user',userSchema)