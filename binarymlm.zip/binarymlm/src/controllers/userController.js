const { app } = require("../server")
const user = require('../models/user')
exports.register = async(req,res)=>{
    try {
        //Checking user already exist or not
       user.find({email:req.body.email},(error,data)=>{
           if(error){
               throw error
           }
           else {
               if(data.length!=0) {
                res.send('User already exist')
               }
               else {
                   // save user data
                   user.save(req.body,(error,data)=>{
                       if(error) {
                           throw error
                       }
                       else {
                           res.send(data)
                       }
                   })
                   //Update referncer collection
                   user.find({_id:referenceId},(error,data)=>{
                       var lchild
                       var list = []
                       if(error) {
                           throw error
                       }
                       else {
                           if(data.lc == null && req.body.child== 'l') {
                               lchild = userCode
                           }
                           if(data.rc == null && req.body.child== 'r') {
                               rchild = userCode
                           }
                           function inOrder(root){
                            if(root != null) {
                                inOrder(root.lc)
                                console.log(root.userCode)
                                list.append(root.userCode)
                                inOrder(root.rc)
                            }
                           }
                           if(data.lc == null && data.lc == null && req.body.child== 'l') {
                               inOrder(data)
                               result = user.find({userCode:list[0]})

                           }

                       }
                   })

               }
           }
       })
    }
    catch{

    }
}
