

exports.generteRefferalCode = async () => {
}